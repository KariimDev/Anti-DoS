#!/bin/bash
# ═══════════════════════════════════════════════════
#   🛡️  SENTINEL SHIELD - UNIVERSAL DEPLOYMENT
#   Drop-in DDoS protection for ANY server.
# ═══════════════════════════════════════════════════

set -e

echo ""
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║   🛡️  SENTINEL SHIELD INSTALLER  v2.5        ║"
echo "  ║   Advanced DoS Mitigation Intelligence       ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo ""

# ──────────────────────────────────────────────────
# 1. PREREQUISITES CHECK
# ──────────────────────────────────────────────────

if ! [ -x "$(command -v docker)" ]; then
  echo "  ❌ Docker is NOT installed."
  echo "  Please install Docker first: https://docs.docker.com/get-docker/"
  exit 1
fi

if ! docker compose version &>/dev/null && ! docker-compose version &>/dev/null; then
  echo "  ❌ Docker Compose is NOT installed."
  echo "  Please install Docker Compose: https://docs.docker.com/compose/install/"
  exit 1
fi

# Determine the compose command (v2 plugin vs v1 standalone)
if docker compose version &>/dev/null; then
  COMPOSE_CMD="docker compose"
else
  COMPOSE_CMD="docker-compose"
fi

echo "  ✅ Docker detected."
echo ""

# ──────────────────────────────────────────────────
# 2. INTERACTIVE CONFIGURATION
# ──────────────────────────────────────────────────

echo "  ┌─────────────────────────────────────────────┐"
echo "  │         DEPLOYMENT CONFIGURATION             │"
echo "  └─────────────────────────────────────────────┘"
echo ""

# --- Question 1: What port is your server running on? ---
echo "  📡 What port is the server you want to PROTECT running on?"
echo "     (This is your existing app/website — e.g. 3000, 4000, 8080)"
read -rp "     ➤ Target server port: " TARGET_PORT

# Validate
if ! [[ "$TARGET_PORT" =~ ^[0-9]+$ ]] || [ "$TARGET_PORT" -lt 1 ] || [ "$TARGET_PORT" -gt 65535 ]; then
  echo "  ❌ Invalid port number. Must be 1-65535."
  exit 1
fi

echo ""

# --- Question 2: What port should the Shield proxy listen on? ---
echo "  🛡️  What port should Sentinel Shield listen on?"
echo "     (Clients will connect to THIS port instead of $TARGET_PORT)"
echo "     (e.g. 80, 8081, 443 — anything you want)"
read -rp "     ➤ Shield proxy port: " SHIELD_PORT

if ! [[ "$SHIELD_PORT" =~ ^[0-9]+$ ]] || [ "$SHIELD_PORT" -lt 1 ] || [ "$SHIELD_PORT" -gt 65535 ]; then
  echo "  ❌ Invalid port number. Must be 1-65535."
  exit 1
fi

if [ "$SHIELD_PORT" = "$TARGET_PORT" ]; then
  echo "  ❌ Shield port cannot be the same as target port."
  exit 1
fi

echo ""

# --- Question 3: Dashboard admin key ---
echo "  🔑 Choose a SECRET KEY to access the Sentinel Dashboard."
echo "     (You will enter this in the browser to unlock the HUD)"
read -rsp "     ➤ Admin secret key: " ADMIN_KEY
echo ""

if [ -z "$ADMIN_KEY" ]; then
  echo "  ❌ Admin key cannot be empty."
  exit 1
fi

echo ""

# ──────────────────────────────────────────────────
# 3. STOP OLD CONTAINERS (if running)
# ──────────────────────────────────────────────────

echo "  🧹 Stopping any previous Sentinel Shield containers..."
$COMPOSE_CMD down 2>/dev/null || true
docker rm -f sentinel-shield sentinel-redis 2>/dev/null || true
echo "  ✅ Clean slate."
echo ""

# ──────────────────────────────────────────────────
# 4. GENERATE CONFIGURATION
# ──────────────────────────────────────────────────

echo "  ⚙️  Generating configuration..."

cat > .env <<ENVEOF
# Sentinel Shield Configuration (Auto-generated)
TARGET_PORT=${TARGET_PORT}
SHIELD_PORT=${SHIELD_PORT}
BACKEND_URL=http://host.docker.internal:${TARGET_PORT}
USE_REDIS=true
ADMIN_KEY=${ADMIN_KEY}
RL_CAPACITY=20
RL_REFILL_RATE=5
RL_TTL_SECONDS=600
ENVEOF

echo "  ✅ .env created."

# ──────────────────────────────────────────────────
# 5. GENERATE DOCKER-COMPOSE
# ──────────────────────────────────────────────────

cat > docker-compose.yml <<COMPEOF
services:
  redis:
    image: redis:alpine
    container_name: sentinel-redis
    restart: always
    expose:
      - "6379"

  shield:
    build: ./Shield-Proxy
    container_name: sentinel-shield
    restart: always
    depends_on:
      - redis
    ports:
      - "${SHIELD_PORT}:${SHIELD_PORT}"
    environment:
      - SHIELD_PORT=${SHIELD_PORT}
      - BACKEND_URL=http://host.docker.internal:${TARGET_PORT}
      - USE_REDIS=true
      - REDIS_URL=redis://redis:6379
      - ADMIN_KEY=${ADMIN_KEY}
    extra_hosts:
      - "host.docker.internal:host-gateway"
COMPEOF

echo "  ✅ docker-compose.yml created."
echo ""

# Show what was generated for debug
echo "  📋 Generated config:"
echo "     Target port (your server):  $TARGET_PORT"
echo "     Shield port (proxy):        $SHIELD_PORT"
echo "     Backend URL:                http://host.docker.internal:$TARGET_PORT"
echo ""

# ──────────────────────────────────────────────────
# 6. BUILD & LAUNCH
# ──────────────────────────────────────────────────

echo "  🏗️  Building Sentinel Shield containers (this may take a minute)..."
$COMPOSE_CMD build --no-cache

echo ""
echo "  🚀 Launching Sentinel Shield..."
$COMPOSE_CMD up -d

# ──────────────────────────────────────────────────
# 7. VERIFY DEPLOYMENT
# ──────────────────────────────────────────────────

echo ""
echo "  ⏳ Waiting for containers to start..."
sleep 5

# Check if the shield container is running
if docker ps --format '{{.Names}}' | grep -q sentinel-shield; then
  echo "  ✅ sentinel-shield container is RUNNING"
else
  echo "  ❌ sentinel-shield container FAILED to start!"
  echo ""
  echo "  📋 Container logs:"
  docker logs sentinel-shield 2>&1 | tail -30
  exit 1
fi

# Verify port mapping actually happened
MAPPED_PORT=$(docker inspect sentinel-shield --format='{{(index (index .NetworkSettings.Ports "'$SHIELD_PORT'/tcp") 0).HostPort}}' 2>/dev/null || echo "FAILED")

if [ "$MAPPED_PORT" == "FAILED" ] || [ -z "$MAPPED_PORT" ]; then
  echo "  ⚠️  Port mapping check failed. Docker might not have exposed the port correctly."
  echo "     Check if port $SHIELD_PORT is already used by another application."
else
  echo "  ✅ Host port $MAPPED_PORT successfully mapped to container port $SHIELD_PORT."
fi

# Check if Redis is running
if docker ps --format '{{.Names}}' | grep -q sentinel-redis; then
  echo "  ✅ sentinel-redis container is RUNNING"
else
  echo "  ⚠️  sentinel-redis container is NOT running (Shield will use memory mode)"
fi

# Show container ports
echo ""
echo "  📋 Active port mappings:"
docker ps --format 'table {{.Names}}\t{{.Ports}}' | grep sentinel

# Try to hit the health endpoint
echo ""
echo "  🔍 Testing Shield health endpoint..."
sleep 2
if curl -s --max-time 5 "http://localhost:${SHIELD_PORT}/health" > /dev/null 2>&1; then
  echo "  ✅ Shield is responding on port ${SHIELD_PORT}!"
else
  echo "  ⚠️  Shield not responding yet on port ${SHIELD_PORT}."
  echo "     Checking container logs..."
  echo ""
  docker logs sentinel-shield 2>&1 | tail -15
  echo ""
  echo "     The container might still be starting. Try:"
  echo "     curl http://localhost:${SHIELD_PORT}/health"
fi

echo ""
echo "  ╔═══════════════════════════════════════════════════════════╗"
echo "  ║              ✅  DEPLOYMENT COMPLETE                     ║"
echo "  ╠═══════════════════════════════════════════════════════════╣"
echo "  ║                                                          ║"
echo "  ║  🛡️  Protecting server on port $TARGET_PORT"
echo "  ║                                                          ║"
echo "  ║  🌐  Send traffic to:  http://YOUR-IP:$SHIELD_PORT"
echo "  ║      (instead of port $TARGET_PORT)"
echo "  ║                                                          ║"
echo "  ║  📊  Dashboard:  http://YOUR-IP:$SHIELD_PORT/sentinel"
echo "  ║      (use your secret key to log in)                     ║"
echo "  ║                                                          ║"
echo "  ╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "  📋 Useful commands:"
echo "     docker logs sentinel-shield     — view Shield logs"
echo "     docker logs sentinel-redis      — view Redis logs"
echo "     $COMPOSE_CMD down               — stop everything"
echo "     $COMPOSE_CMD up -d              — restart"
echo ""
