#!/bin/bash
# ═══════════════════════════════════════════════════
#   🛡️  SENTINEL SHIELD - UNIVERSAL DEPLOYMENT
#   Drop-in DDoS protection for ANY server.
# ═══════════════════════════════════════════════════

set -e

echo ""
echo "  ╔═══════════════════════════════════════════════╗"
echo "  ║   🛡️  SENTINEL SHIELD INSTALLER  v2.5        ║"
echo "  ║   Advanced DoS Mitigation Intelligence       ║"
echo "  ╚═══════════════════════════════════════════════╝"
echo ""

# ──────────────────────────────────────────────────
# 1. PREREQUISITES CHECK
# ──────────────────────────────────────────────────

if ! [ -x "$(command -v docker)" ]; then
  echo "  ❌ Docker is NOT installed."
  echo "  Please install Docker first: https://docs.docker.com/get-docker/"
  exit 1
fi

if ! docker compose version &>/dev/null && ! docker-compose version &>/dev/null; then
  echo "  ❌ Docker Compose is NOT installed."
  echo "  Please install Docker Compose: https://docs.docker.com/compose/install/"
  exit 1
fi

# Determine the compose command (v2 plugin vs v1 standalone)
if docker compose version &>/dev/null; then
  COMPOSE_CMD="docker compose"
else
  COMPOSE_CMD="docker-compose"
fi

echo "  ✅ Docker detected."
echo ""

# ──────────────────────────────────────────────────
# 2. INTERACTIVE CONFIGURATION
# ──────────────────────────────────────────────────

echo "  ┌─────────────────────────────────────────────┐"
echo "  │         DEPLOYMENT CONFIGURATION             │"
echo "  └─────────────────────────────────────────────┘"
echo ""

# --- Question 1: What port is your server running on? ---
echo "  📡 What port is the server you want to PROTECT running on?"
echo "     (This is your existing app/website — e.g. 3000, 4000, 8080)"
read -rp "     ➤ Target server port: " TARGET_PORT

# Validate
if ! [[ "$TARGET_PORT" =~ ^[0-9]+$ ]] || [ "$TARGET_PORT" -lt 1 ] || [ "$TARGET_PORT" -gt 65535 ]; then
  echo "  ❌ Invalid port number. Must be 1-65535."
  exit 1
fi

echo ""

# --- Question 2: What port should the Shield proxy listen on? ---
echo "  🛡️  What port should Sentinel Shield listen on?"
echo "     (Clients will connect to THIS port instead of $TARGET_PORT)"
echo "     (e.g. 80, 8081, 443 — anything you want)"
read -rp "     ➤ Shield proxy port: " SHIELD_PORT

if ! [[ "$SHIELD_PORT" =~ ^[0-9]+$ ]] || [ "$SHIELD_PORT" -lt 1 ] || [ "$SHIELD_PORT" -gt 65535 ]; then
  echo "  ❌ Invalid port number. Must be 1-65535."
  exit 1
fi

if [ "$SHIELD_PORT" = "$TARGET_PORT" ]; then
  echo "  ❌ Shield port cannot be the same as target port."
  exit 1
fi

echo ""

# --- Question 3: Dashboard admin key ---
echo "  🔑 Choose a SECRET KEY to access the Sentinel Dashboard."
echo "     (You will enter this in the browser to unlock the HUD)"
read -rsp "     ➤ Admin secret key: " ADMIN_KEY
echo ""

if [ -z "$ADMIN_KEY" ]; then
  echo "  ❌ Admin key cannot be empty."
  exit 1
fi

echo ""

# ──────────────────────────────────────────────────
# 3. GENERATE CONFIGURATION
# ──────────────────────────────────────────────────

echo "  ⚙️  Generating configuration..."

cat > .env <<EOF
# ═══════════════════════════════════════════════════
# Sentinel Shield Configuration (Auto-generated)
# ═══════════════════════════════════════════════════

# The port YOUR server is running on (the one we're protecting)
TARGET_PORT=${TARGET_PORT}

# The port Sentinel Shield listens on (public-facing)
SHIELD_PORT=${SHIELD_PORT}

# Internal URL to reach your server from inside Docker
BACKEND_URL=http://host.docker.internal:${TARGET_PORT}

# Redis for distributed rate-limiting (always enabled in Docker mode)
USE_REDIS=true

# Dashboard access key
ADMIN_KEY=${ADMIN_KEY}

# Token Bucket configuration (tune if needed)
RL_CAPACITY=20
RL_REFILL_RATE=5
RL_TTL_SECONDS=600
EOF

echo "  ✅ .env created."

# ──────────────────────────────────────────────────
# 4. GENERATE DOCKER-COMPOSE
# ──────────────────────────────────────────────────

cat > docker-compose.yml <<EOF
services:
  redis:
    image: redis:alpine
    container_name: sentinel-redis
    restart: always
    expose:
      - "6379"

  shield:
    build: ./Shield-Proxy
    container_name: sentinel-shield
    restart: always
    depends_on:
      - redis
    ports:
      - "${SHIELD_PORT}:${SHIELD_PORT}"
    environment:
      - SHIELD_PORT=${SHIELD_PORT}
      - BACKEND_URL=http://host.docker.internal:${TARGET_PORT}
      - USE_REDIS=true
      - REDIS_URL=redis://redis:6379
      - ADMIN_KEY=${ADMIN_KEY}
    extra_hosts:
      - "host.docker.internal:host-gateway"
EOF

echo "  ✅ docker-compose.yml created."

# ──────────────────────────────────────────────────
# 5. BUILD & LAUNCH
# ──────────────────────────────────────────────────

echo ""
echo "  🏗️  Building Sentinel Shield containers..."
$COMPOSE_CMD build

echo ""
echo "  🚀 Launching Sentinel Shield..."
$COMPOSE_CMD up -d

echo ""
echo "  ╔═══════════════════════════════════════════════════════════╗"
echo "  ║              ✅  DEPLOYMENT SUCCESSFUL                   ║"
echo "  ╠═══════════════════════════════════════════════════════════╣"
echo "  ║                                                          ║"
echo "  ║  🛡️  Shield is now protecting port ${TARGET_PORT}              "
echo "  ║                                                          ║"
echo "  ║  🌐  Send traffic to:  http://YOUR-IP:${SHIELD_PORT}          "
echo "  ║      (instead of port ${TARGET_PORT})                          "
echo "  ║                                                          ║"
echo "  ║  📊  Dashboard:  http://YOUR-IP:${SHIELD_PORT}/sentinel       "
echo "  ║      (use your secret key to log in)                     ║"
echo "  ║                                                          ║"
echo "  ╚═══════════════════════════════════════════════════════════╝"
echo ""
echo "  💡 TIP: Point your domain/DNS to this server's IP on port ${SHIELD_PORT}"
echo "     and Sentinel will filter all traffic before it reaches your app."
echo ""
